# Конфигурации API и ключей

OPENAI_API_KEY = 'your-api-key-here'